<?php
echo "看！有怪兽&nbsp &nbsp(σ′▽‵)′▽‵)σ";