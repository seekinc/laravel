<?php
$connection=@mysqli_connect("43.129.243.195","class","Chi123..@","class","33307") or die("数据库连接失败!");
return $connection;